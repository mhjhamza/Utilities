class HelloHamza:
    def __init__(self):
        pass

    @staticmethod
    def sayHello():
        print('Hello Hamza')
