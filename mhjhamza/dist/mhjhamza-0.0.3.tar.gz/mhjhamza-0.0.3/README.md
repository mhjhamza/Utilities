Publishing very first Github Repo

PyPI package testing